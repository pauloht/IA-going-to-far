Encog 3.3

The following links will be helpful getting started with Encog.

Getting Started:

http://www.heatonresearch.com/wiki/Getting_Started

Important Links:

http://www.heatonresearch.com/encog
http://www.heatonresearch.com/wiki